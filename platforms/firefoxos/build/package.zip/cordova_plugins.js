cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-websocket": "0.9.2"
}
// BOTTOM OF METADATA
});